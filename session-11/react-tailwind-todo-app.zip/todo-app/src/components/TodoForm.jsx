import { useState } from 'react'

function TodoForm({ onAddTodo }) {
  const [title, setTitle] = useState('')

  const handleSubmit = (event) => {
    event.preventDefault()
    onAddTodo(title)
    setTitle('')
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-3 sm:flex-row">
      <label htmlFor="todo-title" className="sr-only">
        New task title
      </label>
      <input
        id="todo-title"
        type="text"
        value={title}
        onChange={(event) => setTitle(event.target.value)}
        placeholder="Add a new task..."
        className="min-h-12 flex-1 rounded-2xl border border-slate-300 px-4 text-slate-900 outline-none transition focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100"
      />

      <button
        type="submit"
        className="min-h-12 rounded-2xl bg-indigo-600 px-6 font-semibold text-white transition hover:bg-indigo-700 focus:outline-none focus:ring-4 focus:ring-indigo-200"
      >
        Add Task
      </button>
    </form>
  )
}

export default TodoForm
