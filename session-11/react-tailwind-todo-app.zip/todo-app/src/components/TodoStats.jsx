function TodoStats({ todos }) {
  const totalTasks = todos.length
  const completedTasks = todos.filter((todo) => todo.completed).length
  const activeTasks = totalTasks - completedTasks

  const stats = [
    { label: 'Total', value: totalTasks },
    { label: 'Active', value: activeTasks },
    { label: 'Completed', value: completedTasks },
  ]

  return (
    <div className="mt-6 grid grid-cols-3 gap-3">
      {stats.map((stat) => (
        <div key={stat.label} className="rounded-2xl bg-slate-100 p-4 text-center">
          <p className="text-2xl font-bold text-slate-900">{stat.value}</p>
          <p className="text-sm font-medium text-slate-500">{stat.label}</p>
        </div>
      ))}
    </div>
  )
}

export default TodoStats
