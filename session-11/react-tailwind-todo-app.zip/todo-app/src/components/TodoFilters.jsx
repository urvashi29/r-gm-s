const filters = [
  { label: 'All', value: 'all' },
  { label: 'Active', value: 'active' },
  { label: 'Completed', value: 'completed' },
]

function TodoFilters({
  currentFilter,
  onChangeFilter,
  onClearCompleted,
  hasCompletedTodos,
}) {
  return (
    <div className="mt-6 flex flex-col gap-3 border-t border-slate-200 pt-5 sm:flex-row sm:items-center sm:justify-between">
      <div className="flex rounded-2xl bg-slate-100 p-1" aria-label="Task filters">
        {filters.map((filter) => (
          <button
            key={filter.value}
            type="button"
            onClick={() => onChangeFilter(filter.value)}
            className={`rounded-xl px-4 py-2 text-sm font-semibold transition ${
              currentFilter === filter.value
                ? 'bg-white text-indigo-700 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {filter.label}
          </button>
        ))}
      </div>

      <button
        type="button"
        onClick={onClearCompleted}
        disabled={!hasCompletedTodos}
        className="rounded-xl px-4 py-2 text-sm font-semibold text-rose-700 transition hover:bg-rose-50 disabled:cursor-not-allowed disabled:text-slate-400 disabled:hover:bg-transparent"
      >
        Clear Completed
      </button>
    </div>
  )
}

export default TodoFilters
