import { useState } from 'react'

function TodoItem({ todo, onToggleTodo, onEditTodo, onDeleteTodo }) {
  const [isEditing, setIsEditing] = useState(false)
  const [editedTitle, setEditedTitle] = useState(todo.title)

  const handleSave = () => {
    if (!editedTitle.trim()) return
    onEditTodo(todo.id, editedTitle)
    setIsEditing(false)
  }

  const handleCancel = () => {
    setEditedTitle(todo.title)
    setIsEditing(false)
  }

  const handleKeyDown = (event) => {
    if (event.key === 'Enter') {
      handleSave()
    }

    if (event.key === 'Escape') {
      handleCancel()
    }
  }

  return (
    <article className="flex flex-col gap-3 rounded-2xl border border-slate-200 bg-slate-50 p-4 sm:flex-row sm:items-center sm:justify-between">
      <div className="flex flex-1 items-center gap-3">
        <input
          type="checkbox"
          checked={todo.completed}
          onChange={() => onToggleTodo(todo.id)}
          className="h-5 w-5 rounded border-slate-300 accent-indigo-600"
          aria-label={`Mark ${todo.title} as completed`}
        />

        {isEditing ? (
          <input
            type="text"
            value={editedTitle}
            onChange={(event) => setEditedTitle(event.target.value)}
            onKeyDown={handleKeyDown}
            className="min-h-10 flex-1 rounded-xl border border-slate-300 px-3 outline-none focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100"
            autoFocus
          />
        ) : (
          <p
            className={`flex-1 text-base font-medium ${
              todo.completed ? 'text-slate-400 line-through' : 'text-slate-800'
            }`}
          >
            {todo.title}
          </p>
        )}
      </div>

      <div className="flex gap-2 sm:justify-end">
        {isEditing ? (
          <>
            <button
              type="button"
              onClick={handleSave}
              className="rounded-xl bg-emerald-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-emerald-700"
            >
              Save
            </button>
            <button
              type="button"
              onClick={handleCancel}
              className="rounded-xl bg-slate-200 px-4 py-2 text-sm font-semibold text-slate-700 transition hover:bg-slate-300"
            >
              Cancel
            </button>
          </>
        ) : (
          <button
            type="button"
            onClick={() => setIsEditing(true)}
            className="rounded-xl bg-slate-200 px-4 py-2 text-sm font-semibold text-slate-700 transition hover:bg-slate-300"
          >
            Edit
          </button>
        )}

        <button
          type="button"
          onClick={() => onDeleteTodo(todo.id)}
          className="rounded-xl bg-rose-100 px-4 py-2 text-sm font-semibold text-rose-700 transition hover:bg-rose-200"
        >
          Delete
        </button>
      </div>
    </article>
  )
}

export default TodoItem
