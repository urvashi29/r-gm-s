import { useEffect, useMemo, useState } from 'react'
import TodoFilters from './components/TodoFilters.jsx'
import TodoForm from './components/TodoForm.jsx'
import TodoItem from './components/TodoItem.jsx'
import TodoStats from './components/TodoStats.jsx'

const STORAGE_KEY = 'react-tailwind-todos'

function getInitialTodos() {
  try {
    const savedTodos = localStorage.getItem(STORAGE_KEY)
    return savedTodos ? JSON.parse(savedTodos) : []
  } catch (error) {
    console.warn('Unable to read saved todos:', error)
    return []
  }
}

function App() {
  const [todos, setTodos] = useState(getInitialTodos)
  const [filter, setFilter] = useState('all')

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(todos))
  }, [todos])

  const addTodo = (title) => {
    const trimmedTitle = title.trim()

    if (!trimmedTitle) return

    const newTodo = {
      id: crypto.randomUUID(),
      title: trimmedTitle,
      completed: false,
      createdAt: new Date().toISOString(),
    }

    setTodos((currentTodos) => [newTodo, ...currentTodos])
  }

  const toggleTodo = (id) => {
    setTodos((currentTodos) =>
      currentTodos.map((todo) =>
        todo.id === id ? { ...todo, completed: !todo.completed } : todo,
      ),
    )
  }

  const editTodo = (id, updatedTitle) => {
    const trimmedTitle = updatedTitle.trim()

    if (!trimmedTitle) return

    setTodos((currentTodos) =>
      currentTodos.map((todo) =>
        todo.id === id ? { ...todo, title: trimmedTitle } : todo,
      ),
    )
  }

  const deleteTodo = (id) => {
    setTodos((currentTodos) => currentTodos.filter((todo) => todo.id !== id))
  }

  const clearCompletedTodos = () => {
    setTodos((currentTodos) => currentTodos.filter((todo) => !todo.completed))
  }

  const filteredTodos = useMemo(() => {
    if (filter === 'active') {
      return todos.filter((todo) => !todo.completed)
    }

    if (filter === 'completed') {
      return todos.filter((todo) => todo.completed)
    }

    return todos
  }, [todos, filter])

  return (
    <main className="min-h-screen bg-slate-100 px-4 py-10 text-slate-900">
      <section className="mx-auto max-w-3xl">
        <div className="mb-8 text-center">
          <p className="mb-2 text-sm font-semibold uppercase tracking-[0.25em] text-indigo-600">
            React + Tailwind CSS
          </p>
          <h1 className="text-4xl font-bold tracking-tight sm:text-5xl">
            To-Do Application
          </h1>
          <p className="mt-3 text-slate-600">
            Organize tasks, track progress, and keep your list saved in the browser.
          </p>
        </div>

        <div className="rounded-3xl bg-white p-5 shadow-xl shadow-slate-200 sm:p-8">
          <TodoForm onAddTodo={addTodo} />

          <TodoStats todos={todos} />

          <TodoFilters
            currentFilter={filter}
            onChangeFilter={setFilter}
            onClearCompleted={clearCompletedTodos}
            hasCompletedTodos={todos.some((todo) => todo.completed)}
          />

          <div className="mt-6 space-y-3" aria-live="polite">
            {filteredTodos.length > 0 ? (
              filteredTodos.map((todo) => (
                <TodoItem
                  key={todo.id}
                  todo={todo}
                  onToggleTodo={toggleTodo}
                  onEditTodo={editTodo}
                  onDeleteTodo={deleteTodo}
                />
              ))
            ) : (
              <div className="rounded-2xl border border-dashed border-slate-300 p-8 text-center">
                <p className="text-lg font-semibold text-slate-700">No tasks found</p>
                <p className="mt-1 text-sm text-slate-500">
                  Add a new task or switch to another filter.
                </p>
              </div>
            )}
          </div>
        </div>
      </section>
    </main>
  )
}

export default App
