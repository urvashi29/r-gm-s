# React Tailwind To-Do App

A clean, responsive to-do application built with React, Vite, Tailwind CSS, and browser `localStorage`.

## Features

- Add new tasks
- Mark tasks as completed
- Edit tasks
- Delete tasks
- Filter tasks by All, Active, and Completed
- Clear completed tasks
- View total, active, and completed counts
- Persist tasks after browser refresh using `localStorage`

## Project Structure

```text
react-tailwind-todo-app/
├── src/
│   ├── components/
│   │   ├── TodoFilters.jsx
│   │   ├── TodoForm.jsx
│   │   ├── TodoItem.jsx
│   │   └── TodoStats.jsx
│   ├── App.jsx
│   ├── index.css
│   └── main.jsx
├── index.html
├── package.json
├── vite.config.js
└── README.md
```

## Run Locally

```bash
npm install
npm run dev
```

Open the local URL shown in your terminal, usually:

```text
http://localhost:5173
```

## Build for Production

```bash
npm run build
npm run preview
```

## Learning Goals

This project is suitable for React beginners who want to practice components, props, state, conditional rendering, list rendering, forms, array methods, and local browser storage.
